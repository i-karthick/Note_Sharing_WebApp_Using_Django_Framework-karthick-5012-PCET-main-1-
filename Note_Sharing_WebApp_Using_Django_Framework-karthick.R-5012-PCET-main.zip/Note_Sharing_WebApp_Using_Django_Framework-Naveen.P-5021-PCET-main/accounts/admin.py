from django.contrib import admin
from .models import *
admin.site.register(user)
admin.site.register(notes)
# Register your models here.
